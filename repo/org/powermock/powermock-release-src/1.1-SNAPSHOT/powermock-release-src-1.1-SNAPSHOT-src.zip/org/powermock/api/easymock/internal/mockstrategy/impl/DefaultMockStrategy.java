package org.powermock.api.easymock.internal.mockstrategy.impl;

import org.easymock.internal.MocksControl.MockType;

public class DefaultMockStrategy extends AbstractMockStrategyBase {

	public DefaultMockStrategy() {
		super(MockType.DEFAULT);
	}
}
